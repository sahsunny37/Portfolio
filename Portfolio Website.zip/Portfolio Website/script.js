// Typing animations
var typed = new Typed(".typing",{
    strings: ["Functional Tester","Java Developer","Automation Tester","Front-End Developer","Fresher","Quality Engineer Associates"],
    typeSpeed:100,
    backSpeed:60,
    loop: true
})

var typed = new Typed(".typing-2",{
    strings: ["Functional Tester","Java Developer","Automation Tester","Front-End Developer","Fresher","Quality Engineer Associates"],
    typeSpeed:99,
    backSpeed:58,
    loop: true
})